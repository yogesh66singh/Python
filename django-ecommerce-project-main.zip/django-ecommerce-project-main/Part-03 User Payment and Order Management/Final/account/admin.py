from django.contrib import admin

from .models import UserBase

admin.site.register(UserBase)
